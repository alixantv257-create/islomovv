#!/usr/bin/env python3
"""
Quick demo to test local voice cloning via LocalSpeechClient.

Usage:
  python scripts/run_local_demo.py reference.wav "Text to speak" out.wav

This will start (or reuse) the local Fish Speech server, download models if needed,
and synthesize `Text to speak` using `reference.wav` as the voice reference.
"""

from __future__ import annotations

import os
import sys

from local_speech_client import LocalSpeechClient


def main() -> None:
    if len(sys.argv) < 4:
        print("Usage: python scripts/run_local_demo.py reference.wav \"Text to speak\" out.wav")
        sys.exit(2)

    ref_path = sys.argv[1]
    text = sys.argv[2]
    out_path = sys.argv[3]

    if not os.path.exists(ref_path):
        print(f"Reference file not found: {ref_path}")
        sys.exit(2)

    model_dir = os.getenv("FISH_LOCAL_MODEL_DIR", os.path.join(os.getcwd(), "models", "fish"))
    whisper_size = os.getenv("LOCAL_WHISPER_SIZE", "large-v3")
    device = os.getenv("LOCAL_DEVICE", "auto")

    print("Initializing LocalSpeechClient (this may install/download models on first run)...")
    client = LocalSpeechClient(model_dir=model_dir, whisper_size=whisper_size, device=device)

    with open(ref_path, "rb") as f:
        ref_bytes = f.read()

    print("Synthesizing... this can take a while depending on model and hardware")
    audio = client.tts(text, reference_audio=ref_bytes, reference_text=text)

    if not audio:
        print("Synthesis returned empty output")
        sys.exit(1)

    os.makedirs(os.path.dirname(out_path) or ".", exist_ok=True)
    with open(out_path, "wb") as f:
        f.write(audio)

    print(f"Wrote synthesized audio to: {out_path}")


if __name__ == "__main__":
    main()
